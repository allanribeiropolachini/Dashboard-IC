$(function(){
  $("#header").load("Header"); 
});